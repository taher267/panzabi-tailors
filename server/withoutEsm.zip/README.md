# Basic GraphQL

url `http://localhost:2001/graphql`

https://stackoverflow.com/questions/69163990/mongodb-aggregate-and-group-by-subcategories-of-products

https://www.mongodb.com/community/forums/t/how-to-make-aggregation-and-group-by-specific-condition-in-mongoose-node-js/139392
