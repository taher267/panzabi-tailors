export default `<div className='contentData'>
<div className='printCard' style='display:flex;'>
  <div
    className='productsCard' 
    style='width:23mm;'
  >all_product_place
  </div>
  <div className='printDesign' style='display:flex;'>
  <div><p>measure_label_place</p><p>measure_size_place</p></div></div>
</div>
</div>`;
