export default (min, max) => min + (max - min) * Math.random();
