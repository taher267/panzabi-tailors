export default (data) => JSON.parse(JSON.stringify(data));
